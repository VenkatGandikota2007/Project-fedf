export class StudentDashboard {
  constructor(authService, dataService) {
    this.authService = authService;
    this.dataService = dataService;
    this.currentView = 'home';
    this.activeFilter = 'all';
  }

  render(container) {
    const user = this.authService.getCurrentUser();

    container.innerHTML = `
      <nav class="navbar">
        <div class="navbar-brand">Student Wellness Portal</div>
        <div class="navbar-menu">
          <a id="nav-home">Home</a>
          <a id="nav-resources">Resources</a>
          <a id="nav-programs">Programs</a>
          <a id="nav-support">Support</a>
          <a id="nav-my-programs">My Programs</a>
          <a id="nav-logout">Logout</a>
        </div>
      </nav>
      <div id="content-area"></div>
    `;

    this.setupNavigation();
    this.renderHome();
  }

  setupNavigation() {
    document.getElementById('nav-home').addEventListener('click', () => this.renderHome());
    document.getElementById('nav-resources').addEventListener('click', () => this.renderResources());
    document.getElementById('nav-programs').addEventListener('click', () => this.renderPrograms());
    document.getElementById('nav-support').addEventListener('click', () => this.renderSupport());
    document.getElementById('nav-my-programs').addEventListener('click', () => this.renderMyPrograms());
    document.getElementById('nav-logout').addEventListener('click', () => {
      this.authService.logout();
      location.reload();
    });
  }

  renderHome() {
    this.currentView = 'home';
    const user = this.authService.getCurrentUser();
    const contentArea = document.getElementById('content-area');

    contentArea.innerHTML = `
      <div class="container">
        <div style="text-align: center; padding: 48px 0;">
          <h1 style="font-size: 42px; margin-bottom: 16px; color: var(--primary-color);">Welcome, ${user.fullName}!</h1>
          <p style="font-size: 18px; color: var(--text-secondary); max-width: 600px; margin: 0 auto 48px;">
            Your health and wellness journey starts here. Access resources, join programs, and get the support you need.
          </p>
        </div>

        <div class="dashboard-grid">
          <div class="stat-card" style="cursor: pointer;" onclick="document.getElementById('nav-resources').click()">
            <h3>Health Resources</h3>
            <div class="stat-value">${this.dataService.getHealthResources({ publishedOnly: true }).length}</div>
            <div class="stat-label">Available Resources</div>
          </div>

          <div class="stat-card" style="cursor: pointer;" onclick="document.getElementById('nav-programs').click()">
            <h3>Wellness Programs</h3>
            <div class="stat-value">${this.dataService.getWellnessPrograms({ activeOnly: true }).length}</div>
            <div class="stat-label">Active Programs</div>
          </div>

          <div class="stat-card" style="cursor: pointer;" onclick="document.getElementById('nav-my-programs').click()">
            <h3>My Enrollments</h3>
            <div class="stat-value">${this.dataService.getStudentEnrollments(user.id).length}</div>
            <div class="stat-label">Programs Enrolled</div>
          </div>

          <div class="stat-card" style="cursor: pointer;" onclick="document.getElementById('nav-support').click()">
            <h3>Support Services</h3>
            <div class="stat-value">${this.dataService.getSupportServices().filter(s => s.isAvailable).length}</div>
            <div class="stat-label">Available Services</div>
          </div>
        </div>

        <div style="margin-top: 48px;">
          <h2 style="margin-bottom: 24px;">Quick Links</h2>
          <div class="resource-grid">
            <div class="card" style="cursor: pointer;" onclick="document.getElementById('nav-resources').click()">
              <div style="font-size: 48px; text-align: center; margin-bottom: 16px;">📚</div>
              <h3 style="text-align: center; margin-bottom: 8px;">Browse Resources</h3>
              <p style="text-align: center; color: var(--text-secondary);">Access mental health, fitness, and nutrition resources</p>
            </div>

            <div class="card" style="cursor: pointer;" onclick="document.getElementById('nav-programs').click()">
              <div style="font-size: 48px; text-align: center; margin-bottom: 16px;">🏃</div>
              <h3 style="text-align: center; margin-bottom: 8px;">Join Programs</h3>
              <p style="text-align: center; color: var(--text-secondary);">Participate in wellness programs and challenges</p>
            </div>

            <div class="card" style="cursor: pointer;" onclick="document.getElementById('nav-support').click()">
              <div style="font-size: 48px; text-align: center; margin-bottom: 16px;">💬</div>
              <h3 style="text-align: center; margin-bottom: 8px;">Get Support</h3>
              <p style="text-align: center; color: var(--text-secondary);">Connect with counseling and support services</p>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  renderResources() {
    this.currentView = 'resources';
    const resources = this.dataService.getHealthResources({ publishedOnly: true });
    const contentArea = document.getElementById('content-area');

    const categories = ['all', 'mental_health', 'fitness', 'nutrition', 'general'];

    contentArea.innerHTML = `
      <div class="container">
        <h2 style="margin-bottom: 24px;">Health & Wellness Resources</h2>

        <div class="filter-bar">
          ${categories.map(cat => `
            <button class="filter-button ${this.activeFilter === cat ? 'active' : ''}" data-category="${cat}">
              ${cat === 'all' ? 'All' : cat.replace('_', ' ')}
            </button>
          `).join('')}
        </div>

        <div class="resource-grid" id="resources-grid">
          ${this.renderResourceCards(resources)}
        </div>
      </div>

      <div id="resource-detail-modal" class="modal">
        <div class="modal-content">
          <button class="modal-close" id="close-resource-detail">&times;</button>
          <div id="resource-detail-content"></div>
        </div>
      </div>
    `;

    document.querySelectorAll('.filter-button').forEach(btn => {
      btn.addEventListener('click', () => {
        this.activeFilter = btn.dataset.category;
        this.renderResources();
      });
    });

    document.getElementById('close-resource-detail').addEventListener('click', () => {
      document.getElementById('resource-detail-modal').classList.remove('active');
    });

    window.viewResource = (id) => this.viewResourceDetail(id);
  }

  renderResourceCards(resources) {
    const filtered = this.activeFilter === 'all'
      ? resources
      : resources.filter(r => r.category === this.activeFilter);

    if (filtered.length === 0) {
      return `
        <div class="empty-state">
          <div class="empty-state-icon">📚</div>
          <div class="empty-state-text">No resources found in this category</div>
        </div>
      `;
    }

    return filtered.map(r => `
      <div class="resource-card" onclick="window.viewResource('${r.id}')">
        <div class="resource-image">${this.getCategoryIcon(r.category)}</div>
        <div class="resource-content">
          <span class="resource-category category-${r.category}">${r.category.replace('_', ' ')}</span>
          <h3 class="resource-title">${r.title}</h3>
          <p class="resource-description">${r.description}</p>
        </div>
      </div>
    `).join('');
  }

  getCategoryIcon(category) {
    const icons = {
      mental_health: '🧠',
      fitness: '💪',
      nutrition: '🥗',
      general: '❤️'
    };
    return icons[category] || '📖';
  }

  viewResourceDetail(id) {
    const resource = this.dataService.getHealthResource(id);
    const user = this.authService.getCurrentUser();

    this.dataService.logResourceView(user.id, id, 0);

    const modal = document.getElementById('resource-detail-modal');
    const content = document.getElementById('resource-detail-content');

    content.innerHTML = `
      <div style="margin-bottom: 16px;">
        <span class="resource-category category-${resource.category}">${resource.category.replace('_', ' ')}</span>
      </div>
      <h2 style="margin-bottom: 16px;">${resource.title}</h2>
      <p style="color: var(--text-secondary); margin-bottom: 24px; font-size: 16px;">${resource.description}</p>
      <div style="line-height: 1.8; color: var(--text-primary);">
        ${resource.content}
      </div>
    `;

    modal.classList.add('active');
  }

  renderPrograms() {
    this.currentView = 'programs';
    const programs = this.dataService.getWellnessPrograms({ activeOnly: true });
    const user = this.authService.getCurrentUser();
    const enrollments = this.dataService.getStudentEnrollments(user.id);
    const contentArea = document.getElementById('content-area');

    contentArea.innerHTML = `
      <div class="container">
        <h2 style="margin-bottom: 24px;">Wellness Programs</h2>

        <div class="resource-grid">
          ${programs.map(p => {
            const enrolled = enrollments.find(e => e.programId === p.id);
            return `
              <div class="program-card">
                <div class="program-header">
                  <span class="program-type type-${p.type}">${p.type.replace('_', ' ')}</span>
                  <span class="difficulty-badge difficulty-${p.difficultyLevel}">${p.difficultyLevel}</span>
                </div>
                <h3 style="margin-bottom: 12px;">${p.title}</h3>
                <p style="color: var(--text-secondary); margin-bottom: 12px; font-size: 14px;">${p.description}</p>
                <div style="margin-bottom: 12px;">
                  <div style="display: flex; justify-content: space-between; font-size: 12px; color: var(--text-secondary); margin-bottom: 4px;">
                    <span>Duration</span>
                    <span>${p.duration}</span>
                  </div>
                  <div style="font-size: 12px; color: var(--text-secondary);">
                    ${p.schedule}
                  </div>
                </div>
                ${enrolled ? `
                  <div class="progress-bar">
                    <div class="progress-fill" style="width: ${enrolled.progress}%"></div>
                  </div>
                  <div style="text-align: center; font-size: 12px; color: var(--text-secondary); margin-bottom: 12px;">
                    Progress: ${enrolled.progress}%
                  </div>
                  <span class="badge badge-success">Enrolled</span>
                ` : `
                  <button class="btn btn-primary" onclick="window.enrollProgram('${p.id}')">Enroll Now</button>
                `}
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;

    window.enrollProgram = (programId) => this.enrollInProgram(programId);
  }

  enrollInProgram(programId) {
    const user = this.authService.getCurrentUser();
    const result = this.dataService.enrollInProgram(user.id, programId);

    if (result.success) {
      alert('Successfully enrolled in the program!');
      this.renderPrograms();
    } else {
      alert(result.message);
    }
  }

  renderMyPrograms() {
    this.currentView = 'myPrograms';
    const user = this.authService.getCurrentUser();
    const enrollments = this.dataService.getStudentEnrollments(user.id);
    const contentArea = document.getElementById('content-area');

    contentArea.innerHTML = `
      <div class="container">
        <h2 style="margin-bottom: 24px;">My Programs</h2>

        ${enrollments.length === 0 ? `
          <div class="empty-state">
            <div class="empty-state-icon">🏃</div>
            <div class="empty-state-text">You haven't enrolled in any programs yet</div>
            <button class="btn btn-primary" onclick="document.getElementById('nav-programs').click()">Browse Programs</button>
          </div>
        ` : `
          <div class="resource-grid">
            ${enrollments.map(e => {
              const program = this.dataService.getWellnessProgram(e.programId);
              if (!program) return '';

              return `
                <div class="program-card">
                  <div class="program-header">
                    <span class="program-type type-${program.type}">${program.type.replace('_', ' ')}</span>
                    <span class="badge badge-${e.status === 'completed' ? 'success' : e.status === 'active' ? 'info' : 'warning'}">${e.status}</span>
                  </div>
                  <h3 style="margin-bottom: 12px;">${program.title}</h3>
                  <p style="color: var(--text-secondary); margin-bottom: 12px; font-size: 14px;">${program.description}</p>

                  <div class="progress-bar">
                    <div class="progress-fill" style="width: ${e.progress}%"></div>
                  </div>
                  <div style="text-align: center; font-size: 12px; color: var(--text-secondary); margin-bottom: 12px;">
                    Progress: ${e.progress}%
                  </div>

                  ${e.status === 'active' && e.progress < 100 ? `
                    <button class="btn btn-primary btn-small" onclick="window.updateProgress('${e.id}', ${Math.min(e.progress + 10, 100)})">
                      Update Progress +10%
                    </button>
                  ` : ''}

                  <div style="font-size: 12px; color: var(--text-secondary); margin-top: 12px;">
                    Enrolled: ${new Date(e.enrolledAt).toLocaleDateString()}
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        `}
      </div>
    `;

    window.updateProgress = (enrollmentId, newProgress) => {
      this.dataService.updateEnrollmentProgress(enrollmentId, newProgress);
      this.renderMyPrograms();
    };
  }

  renderSupport() {
    this.currentView = 'support';
    const services = this.dataService.getSupportServices().filter(s => s.isAvailable);
    const user = this.authService.getCurrentUser();
    const myRequests = this.dataService.getSupportRequests({ studentId: user.id });
    const contentArea = document.getElementById('content-area');

    contentArea.innerHTML = `
      <div class="container">
        <h2 style="margin-bottom: 24px;">Support Services</h2>

        <div class="tabs">
          <button class="tab active" data-tab="services">Available Services</button>
          <button class="tab" data-tab="requests">My Requests</button>
        </div>

        <div id="tab-services" class="tab-content active">
          ${services.map(s => `
            <div class="service-card">
              <div class="service-header">
                <div class="service-name">${s.name}</div>
                <span class="service-type type-${s.type}">${s.type}</span>
              </div>
              <p style="color: var(--text-secondary); margin-bottom: 12px;">${s.description}</p>
              <div style="margin-bottom: 8px;">
                <strong>Contact:</strong> ${s.contactInfo}
              </div>
              <div style="margin-bottom: 12px;">
                <strong>Available:</strong> ${s.availability}
              </div>
              <button class="btn btn-primary btn-small" onclick="window.requestSupport('${s.id}', '${s.name}')">Request Support</button>
            </div>
          `).join('')}
        </div>

        <div id="tab-requests" class="tab-content">
          ${myRequests.length === 0 ? `
            <div class="empty-state">
              <div class="empty-state-icon">💬</div>
              <div class="empty-state-text">You haven't made any support requests yet</div>
            </div>
          ` : `
            <div class="card">
              <table class="table">
                <thead>
                  <tr>
                    <th>Service</th>
                    <th>Message</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  ${myRequests.map(r => {
                    const service = this.dataService.getSupportService(r.serviceId);
                    return `
                      <tr>
                        <td>${service ? service.name : 'N/A'}</td>
                        <td style="max-width: 300px;">${r.message.substring(0, 50)}${r.message.length > 50 ? '...' : ''}</td>
                        <td>
                          <span class="badge ${
                            r.status === 'resolved' ? 'badge-success' :
                            r.status === 'in_progress' ? 'badge-warning' : 'badge-info'
                          }">${r.status}</span>
                        </td>
                        <td>${new Date(r.createdAt).toLocaleDateString()}</td>
                      </tr>
                    `;
                  }).join('')}
                </tbody>
              </table>
            </div>
          `}
        </div>
      </div>

      <div id="support-request-modal" class="modal">
        <div class="modal-content">
          <button class="modal-close" id="close-support-modal">&times;</button>
          <h2 id="support-modal-title">Request Support</h2>
          <form id="support-request-form">
            <div class="form-group">
              <label>Your Message</label>
              <textarea id="support-message" rows="6" placeholder="Describe your situation or what you need help with..." required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit Request</button>
          </form>
        </div>
      </div>
    `;

    document.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));

        tab.classList.add('active');
        document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
      });
    });

    document.getElementById('close-support-modal').addEventListener('click', () => {
      document.getElementById('support-request-modal').classList.remove('active');
    });

    document.getElementById('support-request-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.submitSupportRequest();
    });

    window.requestSupport = (serviceId, serviceName) => {
      document.getElementById('support-modal-title').textContent = `Request Support: ${serviceName}`;
      document.getElementById('support-request-form').dataset.serviceId = serviceId;
      document.getElementById('support-request-modal').classList.add('active');
    };
  }

  submitSupportRequest() {
    const form = document.getElementById('support-request-form');
    const serviceId = form.dataset.serviceId;
    const message = document.getElementById('support-message').value;
    const user = this.authService.getCurrentUser();

    this.dataService.createSupportRequest(user.id, serviceId, message);

    document.getElementById('support-request-modal').classList.remove('active');
    form.reset();

    alert('Support request submitted successfully! We will get back to you soon.');
    this.renderSupport();
  }
}
